﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using Microsoft.Web.WebSockets;

namespace WebApplication1
{
    public class ChatHandler : WebSocketHandler
    {

        private static Random random = new Random();
        private static WebSocketCollection clients = new WebSocketCollection();

        private static string[] entryMessages = { "megérkezett", "itt van", "uuuuups", "bekukkantott", "kukucskál" };
        private static string[] leaveMessages = { "háj báj", "zumm és már itt sincs", "na, ez elment", "angolosan távozott"};


        private string name;
        private string ip;
        private string color;

        public ChatHandler(string userip)
        {
            this.ip = userip;

            RandomColor();
        }

        private void RandomColor()
        {
            var col = random.Next(3);

            var r = random.Next(0, col == 0 ? 5 : 3);
            var g = random.Next(0, col == 1 ? 5 : 3);
            var b = random.Next(0, col == 2 ? 5 : 3);

            color = string.Format("{{\"r\": {0}, \"g\": {1}, \"b\": {2} }}", r * 51, g * 51, b * 51);
        }

        private void NameIpColor()
        {
            int[] colors = new int[3];

            colors[0] = this.name.ToLower().ToArray().Sum(t=>t) % 255;
            var ipParts = this.ip.Split('.');
            colors[1] = int.Parse(ipParts[2]);
            colors[2] = int.Parse(ipParts[3]);

            var min = Math.Max(Math.Max(colors[0], colors[1]), colors[2]) /2;
            for (int i = 0; i < 3; i++)
            {
                colors[i] = colors[i] - min;
            }

            var max = Math.Max(Math.Max(colors[0], colors[1]), colors[2]);
            var multiplier = 255.0 / max;

            for (int i = 0; i < 3; i++)
            {
                colors[i] = (int) ( colors[i] * multiplier);
            }

            color = string.Format("{{\"r\": {0}, \"g\": {1}, \"b\": {2} }}", colors[0], colors[1], colors[2]);
        }

        public override void OnOpen()
        {
            this.name = this.WebSocketContext.QueryString["username"];
            clients.Add(this);
            //NameIpColor();

            SendMessage(entryMessages[random.Next(entryMessages.Length)]);
        }


        public override void OnMessage(string message)
        {
            if (message == "GIMME A SMILE" || message=="CSÍZ" || message == "SAJT" || message =="CHEESE")
            {
                var smilefile = WebSocketContext.Server.MapPath("~/smile.jpg");
                var smileblob = File.ReadAllBytes(smilefile);
                clients.Broadcast(smileblob);
            }
            else if (message == "DRAG & DROP" || message == "DRAGDROP" || message == "DRAG" || message == "DROP")
            {
                var smilefile = WebSocketContext.Server.MapPath("~/dragdrop.jpg");
                var smileblob = File.ReadAllBytes(smilefile);
                clients.Broadcast(smileblob);
            }
            else if (!string.IsNullOrWhiteSpace(message))
                SendMessage(message);
        }

        

        private void SendMessage(string message)
        {
            if (message.StartsWith("JSON"))
            {
                message = message.Substring(4);
                clients.Broadcast(string.Format("{{ \"name\": \"{0}\", \"message\": {1}, \"ip\": \"{2}\", \"color\": {3}, \"time\": \"{4:HH:mm:ss}\", \"users\": {5}, \"picture\": null, \"json\": \"rajz\" }}", name, message, ip, color, DateTime.Now, clients.Count));
            }
            else
            {
                message = message.Replace("\n", "\\n");
                clients.Broadcast(string.Format("{{ \"name\": \"{0}\", \"message\": \"{1}\", \"ip\": \"{2}\", \"color\": {3}, \"time\": \"{4:HH:mm:ss}\", \"users\": {5}, \"picture\": null }}", name, message, ip, color, DateTime.Now, clients.Count));
            }
        }

        public override void OnMessage(byte[] message)
        {
            clients.Broadcast(message);
        }

        public override void OnClose()
        {
            clients.Remove(this);
            SendMessage(leaveMessages[random.Next(leaveMessages.Length)]);
        }

    }
}
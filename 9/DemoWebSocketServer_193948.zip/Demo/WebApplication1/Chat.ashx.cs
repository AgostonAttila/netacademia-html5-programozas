﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using Microsoft.Web.WebSockets;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for Chat
    /// </summary>
    public class Chat : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            
            if (context.IsWebSocketRequest)
                context.AcceptWebSocketRequest(new ChatHandler(context.Request.UserHostAddress));
          
        }

        public bool IsReusable
        {
            get
            {
                return true;
            }
        }
    }
}